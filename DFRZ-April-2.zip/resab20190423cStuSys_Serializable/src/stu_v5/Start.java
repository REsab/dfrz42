package stu_v5;

public class Start {
    public static void main(String[] args) {
        Menu menu = new Menu(  );
            menu.run();


    }


}


