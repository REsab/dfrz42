package stu_v6;

public class Start {
	public static void main(String[] args) {
		Menu menu=new Menu();
		menu.run();
	}
}
