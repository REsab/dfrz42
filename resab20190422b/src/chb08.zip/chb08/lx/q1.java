package chb08.lx;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class q1 {

    public static void main(String[] args) {

        String fileName= "edu.txt";
        String path ="d://";
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("d://edu.txt"));
            BufferedWriter out1 = new BufferedWriter(new FileWriter("edu.txt"));
            out.write("eduuu") ;
            System.out.println("文件创建成功！");
            out1.write("12333");
            out.close();

            long size = getFileSize("d://edu.txt");
            System.out.println("java.txt文件大小为: " + size);
            File file = new File("d://edu.txt");
            if(file.delete()){
                System.out.println(file.getName() + " 文件已被删除！");
            }else{
                System.out.println("文件删除失败！");
            }


        } catch (IOException e) {
        }


    }

    public static long getFileSize(String filename) {
        File file = new File(filename);
        if (!file.exists() || !file.isFile()) {
            System.out.println("文件不存在");
            return -1;
        }
        return file.length();
    }

}
