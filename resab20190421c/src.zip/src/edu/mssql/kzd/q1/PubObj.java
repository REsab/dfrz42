package edu.mssql.kzd.q1;

public class PubObj {
  public static LoginFrame objLoginFrm;



}
