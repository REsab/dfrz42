package edu.mssql.kzd.q1;

public class Start_q2 {
    public static void main(String[] args) {

        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);


    }
}

