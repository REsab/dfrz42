package edu.mssql.kzd.q1_Second;

public class PubObj {
  public static LoginFrame objLoginFrm;



}
