package edu.mssql.kzd.q1_thred;

public class PubObj {
  public static LoginFrame objLoginFrm;



}
