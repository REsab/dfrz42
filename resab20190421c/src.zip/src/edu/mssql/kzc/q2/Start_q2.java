package edu.mssql.kzc.q2;

public class Start_q2 {
    public static void main(String[] args) {

        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);


    }
}

