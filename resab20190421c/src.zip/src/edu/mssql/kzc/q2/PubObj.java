package edu.mssql.kzc.q2;

public class PubObj {
  public static LoginFrame objLoginFrm;



}
