package edu.mssql.kzc.q1;

public class PubObj {
  public static LoginFrame objLoginFrm;



}
