package Frame_V3;

public class Start_q2 {
    public static void main(String[] args) {

        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);


    }
}

