package Frame_V3;

public class PubObj {
  public static LoginFrame  objLoginFrm;



}
