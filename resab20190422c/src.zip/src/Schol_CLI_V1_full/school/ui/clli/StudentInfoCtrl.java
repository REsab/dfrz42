package Schol_CLI_V1_full.school.ui.clli;

public class StudentInfoCtrl {
}
