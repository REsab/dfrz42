package Schol_CLI_V1_full.school.ui.cli;

public class MenuStudentIfo {
}
