package Schol_CLI_V1_full.school.strart;


import Schol_CLI_V1_full.school.ui.cli.MenuGrade;
import Schol_CLI_V1_full.school.ui.cli.Menu__Main;

public class Start {
    public static void main(String[] args) {

        Menu__Main menu =new Menu__Main();
        menu.run();
    }
}
