package Schol_CLI_V1_full.school.dao;

import Schol_CLI_V1_full.school.bean.StudentInfo;

import java.util.List;

public class StudentInfoDaoImlp  implements  StudentInfoDao{
    @Override
    public Integer insert(StudentInfo bean) {
        return null;
    }

    @Override
    public Integer delete(Integer id) {
        return null;
    }

    @Override
    public Integer update(StudentInfo bean) {
        return null;
    }

    @Override
    public List<StudentInfo> GRADE_LIST() {
        return null;
    }
}
