package bean.mine;

import java.io.Serializable;

public class Supplier implements Serializable {

    private static final long serialVersionUID = -6011121277197686437L;
    private Integer Supplier_ID;
    private String NAME;
    private String Address;
    private String Phone;
    private String Fax;
    private String PostalCode;
    private String ConstactPerson;

    public Supplier() {
    }

    public Integer getSupplier_ID() {
        return Supplier_ID;
    }

    public void setSupplier_ID(Integer supplier_ID) {
        Supplier_ID = supplier_ID;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getFax() {
        return Fax;
    }

    public void setFax(String fax) {
        Fax = fax;
    }

    public String getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }

    public String getConstactPerson() {
        return ConstactPerson;
    }

    public void setConstactPerson(String constactPerson) {
        ConstactPerson = constactPerson;
    }
}
