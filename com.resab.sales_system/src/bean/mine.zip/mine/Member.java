package bean.mine;

import java.io.Serializable;
import java.util.Date;

public class Member implements Serializable {


    private static final long serialVersionUID = -2497392866914609338L;
    private Integer UserId;

    private String UserName;
    private String UserPass;
    private String NickName;
    private String Email;
    private String Mobile;
    private String MyId;
    private String MyIdKey;
    private String RegIp;
    private Date RegDate;
    private String LastLoginIp;
    private String LastLoginTime;
    private String Salt;
    private String Secques;
    private String Status;
    private Integer SortNum;
    private Integer IsDeleted;
    private Integer CreateBy;
    private Integer UpdateBy;
    private Date CreateOn;
    private Date UpdateOn;


    Member(){

    }


    public Integer getUserId() {
        return UserId;
    }

    public void setUserId(Integer userId) {
        UserId = userId;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getUserPass() {
        return UserPass;
    }

    public void setUserPass(String userPass) {
        UserPass = userPass;
    }

    public String getNickName() {
        return NickName;
    }

    public void setNickName(String nickName) {
        NickName = nickName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getMyId() {
        return MyId;
    }

    public void setMyId(String myId) {
        MyId = myId;
    }

    public String getMyIdKey() {
        return MyIdKey;
    }

    public void setMyIdKey(String myIdKey) {
        MyIdKey = myIdKey;
    }

    public String getRegIp() {
        return RegIp;
    }

    public void setRegIp(String regIp) {
        RegIp = regIp;
    }

    public Date getRegDate() {
        return RegDate;
    }

    public void setRegDate(Date regDate) {
        RegDate = regDate;
    }

    public String getLastLoginIp() {
        return LastLoginIp;
    }

    public void setLastLoginIp(String lastLoginIp) {
        LastLoginIp = lastLoginIp;
    }

    public String getLastLoginTime() {
        return LastLoginTime;
    }

    public void setLastLoginTime(String lastLoginTime) {
        LastLoginTime = lastLoginTime;
    }

    public String getSalt() {
        return Salt;
    }

    public void setSalt(String salt) {
        Salt = salt;
    }

    public String getSecques() {
        return Secques;
    }

    public void setSecques(String secques) {
        Secques = secques;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public Integer getSortNum() {
        return SortNum;
    }

    public void setSortNum(Integer sortNum) {
        SortNum = sortNum;
    }

    public Integer getIsDeleted() {
        return IsDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        IsDeleted = isDeleted;
    }

    public Integer getCreateBy() {
        return CreateBy;
    }

    public void setCreateBy(Integer createBy) {
        CreateBy = createBy;
    }

    public Integer getUpdateBy() {
        return UpdateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        UpdateBy = updateBy;
    }

    public Date getCreateOn() {
        return CreateOn;
    }

    public void setCreateOn(Date createOn) {
        CreateOn = createOn;
    }

    public Date getUpdateOn() {
        return UpdateOn;
    }

    public void setUpdateOn(Date updateOn) {
        UpdateOn = updateOn;
    }
}
