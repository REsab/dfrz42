package bean.mine;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class StockPile implements Serializable {


    private static final long serialVersionUID = -5957856034990484219L;
    private Integer StockPile_ID;
    private Integer StoreHOuse_ID;
    private Integer Product_ID;
    private BigDecimal Price;
    private Date LastLeaveDate;

    public StockPile() {
    }

    private Date FirstEnterDate;

    public Integer getStockPile_ID() {
        return StockPile_ID;
    }

    public void setStockPile_ID(Integer stockPile_ID) {
        StockPile_ID = stockPile_ID;
    }

    public Integer getStoreHOuse_ID() {
        return StoreHOuse_ID;
    }

    public void setStoreHOuse_ID(Integer storeHOuse_ID) {
        StoreHOuse_ID = storeHOuse_ID;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public BigDecimal getPrice() {
        return Price;
    }

    public void setPrice(BigDecimal price) {
        Price = price;
    }

    public Integer getProduct_ID() {
        return Product_ID;
    }

    public void setProduct_ID(Integer product_ID) {
        Product_ID = product_ID;
    }



    public Date getLastLeaveDate() {
        return LastLeaveDate;
    }

    public void setLastLeaveDate(Date lastLeaveDate) {
        LastLeaveDate = lastLeaveDate;
    }

    public Date getFirstEnterDate() {
        return FirstEnterDate;
    }

    public void setFirstEnterDate(Date firstEnterDate) {
        FirstEnterDate = firstEnterDate;
    }
}
