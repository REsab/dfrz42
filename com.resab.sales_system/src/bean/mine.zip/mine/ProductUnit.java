package bean.mine;

import java.io.Serializable;
import java.util.Date;

public class ProductUnit implements Serializable {

    private Integer Unit_ID;
    private Integer USerId;
    private String NAME;
    private String Remark;
    private Date CreateDate;

    public Integer getUnit_ID() {
        return Unit_ID;
    }

    public ProductUnit() {
    }

    public void setUnit_ID(Integer unit_ID) {
        Unit_ID = unit_ID;
    }

    public Integer getUSerId() {
        return USerId;
    }

    public void setUSerId(Integer USerId) {
        this.USerId = USerId;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getRemark() {
        return Remark;
    }

    public void setRemark(String remark) {
        Remark = remark;
    }

    public Date getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(Date createDate) {
        CreateDate = createDate;
    }
}
