package bean.mine;

import java.io.Serializable;
import java.util.Date;

public class StoreHouse implements Serializable {


    private static final long serialVersionUID = -4592374377435551868L;
    private Integer StoreHouse_ID;
    private Integer UserId;
    private String Address;
    private String Phone;
    private Date CREATEDate;


    public Integer getStoreHouse_ID() {
        return StoreHouse_ID;
    }

    public void setStoreHouse_ID(Integer storeHouse_ID) {
        StoreHouse_ID = storeHouse_ID;
    }

    public StoreHouse() {
    }

    public Integer getUserId() {
        return UserId;
    }

    public void setUserId(Integer userId) {
        UserId = userId;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public Date getCREATEDate() {
        return CREATEDate;
    }

    public void setCREATEDate(Date CREATEDate) {
        this.CREATEDate = CREATEDate;
    }
}
