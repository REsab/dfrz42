package bean.mine;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Product implements Serializable {
    private Integer Product_ID;
    private Integer Unit_ID;
    private Integer USerId;
    private String NAME;
    private String Remark;
    private BigDecimal Price;
    private Date CreateDate;

    public Integer getProduct_ID() {
        return Product_ID;
    }

    public void setProduct_ID(Integer product_ID) {
        Product_ID = product_ID;
    }

    public BigDecimal getPrice() {
        return Price;
    }

    public void setPrice(BigDecimal price) {
        Price = price;
    }

    public Product() {
    }

    public Integer getUnit_ID() {
        return Unit_ID;
    }

    public void setUnit_ID(Integer unit_ID) {
        Unit_ID = unit_ID;
    }

    public Integer getUSerId() {
        return USerId;
    }

    public void setUSerId(Integer USerId) {
        this.USerId = USerId;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getRemark() {
        return Remark;
    }

    public void setRemark(String remark) {
        Remark = remark;
    }





    public Date getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(Date createDate) {
        CreateDate = createDate;
    }
}
