package bean.mine;

import java.io.Serializable;

public class Customer implements Serializable {


    private static final long serialVersionUID = 873769114984529738L;
    private Integer Customer_ID;
    private String NAME;
    private String Address;
    private String Phone;
    private String Fax;
    private String PostalCode;
    private String ConstactPerson;

    public Integer getCustomer_ID() {
        return Customer_ID;
    }

    public void setCustomer_ID(Integer customer_ID) {
        Customer_ID = customer_ID;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getFax() {
        return Fax;
    }

    public void setFax(String fax) {
        Fax = fax;
    }

    public String getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }

    public String getConstactPerson() {
        return ConstactPerson;
    }

    public void setConstactPerson(String constactPerson) {
        ConstactPerson = constactPerson;
    }

    public Customer() {

    }
}
