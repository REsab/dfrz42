package edu.school.strart;

import edu.school.ui.cli.Menu;

public class Start {
    public static void main(String[] args) {

        Menu menu=new Menu();
        menu.run();;
    }
}
