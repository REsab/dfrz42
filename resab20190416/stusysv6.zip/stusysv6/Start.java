package stusysv6;

public class Start {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu menu=new Menu();
		menu.run();
	}
}
