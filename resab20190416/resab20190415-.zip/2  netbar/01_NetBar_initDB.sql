
  if exists (select *from sysobjects where  name='Record')
  drop table Record
  go
  if exists (select *from sysobjects where name='Computer')
  drop table Computer
  go

  if exists (select *from sysobjects where name ='Card')
  drop table Card
  go


  --��
create table Card(
ID varchar(10) not  null ,
PassWord varchar(50) not null,
Balance int null,
UserName varchar(50)
);

alter table Card
add constraint PK_Card_ID primary key (ID);

execute sp_addextendedproperty 'MS_Description','����,��������ͬ','user','dbo','table',Card,'column', ID;
execute sp_addextendedproperty 'MS_Description','����','user','dbo','table',Card,'column', PassWord;
execute sp_addextendedproperty 'MS_Description','�������','user','dbo','table',Card,'column', Balance;
execute sp_addextendedproperty 'MS_Description','�ֿ�������','user','dbo','table',Card,'column', UserName;

-- ���� 
create table Computer (
ID varchar(10) not null,
OnUser  varchar(1) not null,
Note varchar  (100) null

);

alter table Computer
add constraint PK_Computer_ID primary key (ID);
execute sp_addextendedproperty 'MS_Description','����,��������ֵͬ','user','dbo','table',Computer,'column', ID;
execute sp_addextendedproperty 'MS_Description','�Ƿ�����ʹ��','user','dbo','table',Computer,'column', OnUser;
execute sp_addextendedproperty 'MS_Description','��ע��˵����Ϣ','user','dbo','table',Computer,'column', Note;


--- ��¼
create table Record (
ID numeric not null,
CardId varchar (10) not null,
ComputerID varchar (10) not null,
BeginTime smalldatetime null,
EndTime smalldatetime null,
Fee numeric null ,
totalTime smalldatetime null

);

execute sp_addextendedproperty 'MS_Description','����,����������ֵͬ','user','dbo','table',Record,'column', ID;
execute sp_addextendedproperty 'MS_Description','���,����card����id','user','dbo','table',Record,'column', CardId;
execute sp_addextendedproperty 'MS_Description','���,����computer��id ','user','dbo','table',Record,'column', ComputerID;
execute sp_addextendedproperty 'MS_Description','��ʼ�ϻ�ʱ�� ','user','dbo','table',Record,'column', BeginTime;
execute sp_addextendedproperty 'MS_Description','�»�ʱ��','user','dbo','table',Record,'column', EndTime;
execute sp_addextendedproperty 'MS_Description','����  ','user','dbo','table',Record,'column', Fee;


--Constraint FK_Result_StudentNo_2_Student_StudentNo Foreign Key (StudentNo) references Student(StudentNo),

alter table Record 
add constraint PK_Record_ID primary key (ID);
alter table Record
add constraint FK_Record_CardId_2_Card_ID foreign key(CardId) references [Card](ID);
alter table Record
add constraint FK_Record_ComputerID_2_Computer_ID foreign key (ComputerID) references Computer(ID);



--Լ��
alter table Card
add constraint CK_Card_Balance check (Balance >0 Or Balance<1000);
alter table Computer
add constraint CK_Computer_OnUse check (OnUser =0 Or OnUser =1);

alter table Record
add constraint CK_Record_CardID check (EndTime >BeginTime);
