

insert into Card values('0023_ABC','abc',100,'�ž�');
insert into Card values('0023_ABD','abd',200,'���');
insert into Card values('0023_ABE','abe',300,'�쿡');

select * from Card
