

--��������
insert into Grade (GradeId ,GradeName)values (1,'s1');
insert into Grade (GradeId ,GradeName)values (2,'s2');
insert into Grade (GradeId ,GradeName)values (3,'s3');




insert into Subject (SubjectId,SubjectName,ClassHour,GradeId)values (1,'javaSE',100,1);
insert into Subject (SubjectId,SubjectName,ClassHour,GradeId)values (2,'MSSQL',20,1);

insert into Subject (SubjectId,SubjectName,ClassHour,GradeId)values (4,'javaSE plus',100,2);
insert into Subject (SubjectId,SubjectName,ClassHour,GradeId)values (5,'MSSQL plus',20,2);

insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate ,  Email  )
		 values ('2019031156',123456,'����','��',   2,10086123456,'ѧ������','2014-12-03 17:06:15.433','163@164.com');
   
insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate  )
		values ('user',124563,'�û�','Ů',   1,10086123456,'ѧ������',7);

insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate ,  Email  )
		 values ('guest',123,'�ο�','��',   1,10086123456,'ѧ��ʳ��',1997-9-9,null);
		 
insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate ,  Email  )
		 values ('20190311056',123456,'����','��',   2,10086123456,'ѧ������','2014-12-03 17:06:15.433','163@164.com');

		 
insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate ,  Email  )
		 values ('admin',123456,'����','��',   2,10086123456,'ѧ������','2014-12-03 17:06:15.433','163@164.com');


		 
insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate ,  Email  )
		 values ('admin2',123456,'����','��',   2,10086123456,'ѧ������',7,'163@164.com');
   
insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate ,  Email  )
		values ('user2',124563,'�û�','Ů',   2,10086123456,'ѧ������',7,'163@164.com');

insert into StudentInfo( StudentNo ,  LoginPwd ,  StudentName ,  Sex ,  GradeId ,  Phone,  Addresss ,  BornDate ,  Email  )
		 values ('guest2',123,'�ο�','��',   2,10086123456,'ѧ��ʳ��',1997-9-9,'163@164.com');
	


--����
--insert into Result (StudentNo,StudentResult,ExamDate) values ('S1201302001',80,'2013-09-13');
insert into Result (StudentNo	,SubjectId 	,StudentResult 	,ExamDate )
			 values ('guest',1,66,'2013-09-13');
insert into Result (StudentNo	,SubjectId 	,StudentResult 	,ExamDate )
			 values ('user',1,26,'2013-09-13');
insert into Result (StudentNo	,SubjectId 	,StudentResult 	,ExamDate )
			 values ('admin',1,68,'2013-02-15 00:00:00');
insert into Result (StudentNo	,SubjectId 	,StudentResult 	,ExamDate )
			 values ('2019031156',1,68,'2013-02-15 00:00:00');


select * from Grade;		
select * from Subject;
select * from StudentInfo;
select * from Result;