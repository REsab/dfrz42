--�����꼶��   

--ɾ���ɰ汾 ����
  if exists (select *from sysobjects where  name='Result')
		drop table Result
  if exists (select *from sysobjects where  name='StudentInfo')
		drop table StudentInfo
 if exists (select *from sysobjects where  name='Subject')
		drop table Subject;
  if exists (select *from sysobjects where  name='Grade')
		drop table Grade;
go


--����
create table Grade(
	GradeId int not null ,
	GradeName nvarchar(50) not null
);

--����
alter table Grade
add Constraint PK_Grade_GradeId Primary key (GradeId);

----˵�� �е���˼  
--execute sp_addextendedproperty 'MS_Description','ע��','user','dbo','table',����,'column', ����;
execute sp_addextendedproperty 'MS_Description','�꼶���,��ʶ��','user','dbo','table',Grade,'column',GradeId;
execute sp_addextendedproperty 'MS_Description','�꼶��','user','dbo','table',Grade,'column',GradeName;




--����   Subject
create table Subject (
		SubjectId int Primary Key 
		,SubjectName nvarchar(20) not null 
		,ClassHour int not null
		,GradeId int    --��� 
);


--��� 
alter table Subject
add constraint FK_Subject_GradeId foreign key (GradeId) references Grade;


----˵�� �е���˼  
--execute sp_addextendedproperty 'MS_Description','ע��','user','dbo','table',����,'column', ����;
execute sp_addextendedproperty 'MS_Description','��Ŀ���,��ʶ��','user','dbo','table',Subject,'column',SubjectId;
execute sp_addextendedproperty 'MS_Description','��Ŀ����','user','dbo','table',Subject, 'column',SubjectName;
execute sp_addextendedproperty 'MS_Description','ѧʱ','user','dbo','table',Subject,'column',ClassHour;
execute sp_addextendedproperty 'MS_Description','�꼶���','user','dbo','table',Subject,'column',GradeId;




--����
create table  StudentInfo(
	  StudentNo nvarchar(50) NOT NULL ,
	  LoginPwd nvarchar(20) NOT NULL,
	  StudentName nvarchar(50) NOT NULL,
	  Sex char(2) NOT NULL,
	  GradeId int NOT NULL,
	  Phone nvarchar(255) NOT NULL,
	  Addresss nvarchar(255),
	  BornDate datetime,
	  Email nvarchar(50) 
);

-- ��������   ���  
alter table StudentInfo
Add Constraint PK_StudentInfo_StudentNO Primary Key(StudentNo)
,	constraint FK_StudentInfo_GradeId foreign key (GradeId) references Grade;


----˵�� �е���˼  
--execute sp_addextendedproperty 'MS_Description','ע��','user','dbo','table',����,'column', ����;
execute sp_addextendedproperty 'MS_Description','ѧ��','user','dbo','table',StudentInfo,'column', StudentNo;
execute sp_addextendedproperty 'MS_Description','����','user','dbo','table',StudentInfo,'column', LoginPwd;
execute sp_addextendedproperty 'MS_Description','����','user','dbo','table',StudentInfo,'column', StudentName;
execute sp_addextendedproperty 'MS_Description','�Ա�','user','dbo','table',StudentInfo,'column', Sex;
execute sp_addextendedproperty 'MS_Description','�꼶','user','dbo','table',StudentInfo,'column', GradeId;
execute sp_addextendedproperty 'MS_Description','�ֻ���','user','dbo','table',StudentInfo,'column', Phone;
execute sp_addextendedproperty 'MS_Description','��ַ','user','dbo','table',StudentInfo,'column', Addresss;
execute sp_addextendedproperty 'MS_Description','����','user','dbo','table',StudentInfo,'column', BornDate;
execute sp_addextendedproperty 'MS_Description','�����ʼ�','user','dbo','table',StudentInfo,'column', Email;




--����
create table Result(
	Id int not null identity(1,1)
	,StudentNo nvarchar(50) not null 
	,SubjectId int not null 
	,StudentResult int 
	,ExamDate smalldatetime not null
);

--����
alter table Result
add constraint PK_Result_Id primary key (id);

--���
alter table Result 
add constraint FK_Result_StudnetNo foreign key (StudentNo) references StudentInfo
,	constraint FK_Result_StudentId foreign key (SubjectId) references Subject;


--˵�� 

execute sp_addextendedproperty 'MS_Description','��ʶ��,����1','user','dbo','table',Result,'column',Id;
execute sp_addextendedproperty 'MS_Description','ѧ��','user','dbo','table',Result,'column',StudentNo;
execute sp_addextendedproperty 'MS_Description','������Ŀ','user','dbo','table',Result,'column',SubjectId;
execute sp_addextendedproperty 'MS_Description','����','user','dbo','table',Result,'column',StudentResult;
execute sp_addextendedproperty 'MS_Description','��������','user','dbo','table',Result,'column',ExamDate;


















