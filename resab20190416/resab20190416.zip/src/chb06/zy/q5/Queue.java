package chb06.zy.q5;

import java.util.LinkedList;

public class Queue {

    LinkedList linkedList=new LinkedList();






}
