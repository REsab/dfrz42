package chb07.lx.test.test;

public class MyThread {

    public static void main(String[] args) {




    }



}


