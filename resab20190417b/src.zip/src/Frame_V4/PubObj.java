package Frame_V4;

public class PubObj {
  public static LoginFrame  objLoginFrm;



}
