package Frame_V4;

public class Start_q4 {
    public static void main(String[] args) {

        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);


    }
}

