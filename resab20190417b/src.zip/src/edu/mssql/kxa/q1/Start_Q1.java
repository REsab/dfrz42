package edu.mssql.kxa.q1;

public class Start_Q1 {

    public static void main(String[] args) {
        JDBCforStu_grade.list();




    }



}
