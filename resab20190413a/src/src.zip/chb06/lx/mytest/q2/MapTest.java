package chb06.lx.mytest.q2;

import java.util.HashMap;
import java.util.Map;

public class MapTest {

    public static void main(String[] args) {
        Map<String, String> dogMap = new HashMap<>();
         dogMap.put("雪娜瑞", "欧欧");
        dogMap.put("拉布拉多", "亚亚");
        dogMap.put("雪娜瑞", "美美");
        dogMap.put("拉布拉多", "菲菲");





    }


}
